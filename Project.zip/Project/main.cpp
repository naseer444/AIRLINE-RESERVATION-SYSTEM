#include<iostream>
#include<fstream>
#include <sstream>
#include<string>
using namespace std;
//  Date class 
struct Date {
	int day;
	int month;
	int year;
	void convert(string r) {
		char temp[5];
		int k = 0;//for holding index of temp array
		int count = 0;
		//converting string to date dd/mm/yyyy
		for (int i = 0; r[i] != '\0'; i++) {
			if (r[i] == '/') {
				count++;
				if (count == 1) {
					temp[k] = '\0';
					stringstream con(temp);
					con >> day;
					k = 0;
				}
				if (count == 2) {
					temp[k] = '\0';
					stringstream con(temp);
					con >> month;
					k = 0;
				}
				continue;
			}
			if (count == 0) {
				temp[k] = r[i];
				k++;
			}
			else if (count == 1) {
				temp[k] = r[i];
				k++;
			}
			else if (count == 2) {
				temp[k] = r[i];
				k++;
				if (r[i + 1] == '\0') {
					temp[k] = '\0';
					stringstream con(temp);//string stream for converting strings
					con >> year;
				}
			}
		}
	}
	//some operator overloaded for the class
	void operator =(Date d) {
		day = d.day;
		month = d.month;
		year = d.year;
	}
    friend ostream& operator<<(ostream& output, const Date& D) {
		output << D.day << "/" << D.month<<"/"<<D.year;
		return output;
	}
	bool operator==(Date& d) {
		if (d.day != day)
			return false;
		if (d.month != month)
			return false;
		if (d.year != year)
			return false;
		return true;
	}
};
//Time class for time
struct Time {
	int hours;
	int minutes;
	void convert(string r) {
		char temp[4];
		int k = 0;
		int count = 0;
		for (int i = 0; r[i] != '\0'; i++) {
			if (r[i] == ':') {
				count++;
				if (count == 1) {
					temp[k] = '\0';
					stringstream con(temp);
					con >> hours;
					k = 0;
				}
				continue;
			}
			if (count == 0) {
				temp[k] = r[i];
				k++;
			}
			else if (count == 1) {
				temp[k] = r[i];
				k++;
				if (r[i + 1] == '\0') {
					temp[k] = '\0';
					stringstream con(temp);
					con >> minutes;
				}
			}
		}
	}
	void operator =(Time d) {
		hours = d.hours;
		minutes = d.minutes;
	}
	friend ostream& operator<<(ostream& output, const Time& D) {
		output  << D.hours << ":" << D.minutes;
		return output;
	}
};
//Holds the flights data

struct Edge {
	Edge* next;
	Date date;
	string dest;
	Time flyingT;
	Time landingT;
	int HotelCharges;
	int ticketP;
	string airLine;
	Edge() {
		next = NULL;
		HotelCharges = 0;
	}

};

// Node class for holding flights linked list
struct Node {
	
	string city;
	Date date;
	string dest;
	Time flyingT;
	Time landingT;
	int HotelCharges;
	int ticketP;
	string airLine;
	Node* next;
	Node() {
		next = NULL;
	}

	// Time checker for time gap
	int timeChecker() {
		int hoursF = flyingT.hours;
		int hoursL = landingT.hours;
		int countH = 0; // counts time gap
		while (hoursF != hoursL) {
			hoursF = hoursF % 24;//hours count
			if (hoursF == 0)
				date.day++;
			hoursF++;
			countH++;
		}
		return countH;
	}
};
// List for flight
class List {
	Node* head;
public:
	List() {
		head = NULL;
	}
	void insert(Edge* n,string city) {
		if (head == NULL) {
			Node* node = new Node;
			node->airLine = n->airLine;
			node->city = city;
			node->date = n->date;
			node->dest = n->dest;
			node->flyingT = n->flyingT;
			node->ticketP = n->ticketP;
			node->landingT = n->landingT;
			node->HotelCharges = n->HotelCharges;
			head = node;
		}
		else {
			Node* temp = head;
			while (temp->next)
				temp = temp->next;
			Node* node = new Node;
			node->airLine = n->airLine;
			node->city = city;
			node->date = n->date;
			node->dest = n->dest;
			node->flyingT = n->flyingT;
			node->landingT = n->landingT;
			node->ticketP = n->ticketP;
			node->HotelCharges = n->HotelCharges;
			temp->next = node;
		}
	}
	void insertTransit(Edge* n, string city) {
		if (head == NULL) {
			Node* node = new Node;
			node->airLine = n->airLine;
			node->city = city;
			node->date = n->date;
			node->dest = n->dest;
			node->flyingT = n->flyingT;
			node->ticketP = n->ticketP;
			node->landingT = n->landingT;
			node->HotelCharges = n->HotelCharges;
			head = node;
		}
		else {
			Node* temp = head;
			while (temp->next) {
				if (temp->city == city && temp->dest == n->dest && temp->HotelCharges == n->HotelCharges && temp->date == n->date)
					return;
				temp = temp->next;
			}
			if (temp->city == city && temp->dest == n->dest && temp->HotelCharges == n->HotelCharges && temp->date == n->date)
				return;
			Node* node = new Node;
			node->airLine = n->airLine;
			node->city = city;
			node->date = n->date;
			node->dest = n->dest;
			node->flyingT = n->flyingT;
			node->landingT = n->landingT;
			node->ticketP = n->ticketP;
			node->HotelCharges = n->HotelCharges;
			node->next = NULL;
			temp->next = node;
		}
	}
	void insertNode(Node* node) {
		if (head == NULL) {
			head = node;
		}
		else {
			Node* temp = head;
			while (temp->next) {
				temp = temp->next;
			}

			temp->next = node;
		}
	}
	//sort function for cost
	void sortCost()
	{
		int swapped, i;
		Node* ptr1;
		Node* lptr = NULL;

		if (head == NULL)
			return;

		do
		{
			swapped = 0;
			ptr1 = head;

			while (ptr1->next != lptr)
			{
				if (ptr1->ticketP > ptr1->next->ticketP)
				{
					swap(ptr1, ptr1->next);
					swapped = 1;
				}
				ptr1 = ptr1->next;
			}
			lptr = ptr1;
		} while (swapped);
	}
	//sort function for time
	void sortTime()
	{
		int swapped, i;
		Node* ptr1;
		Node* lptr = NULL;

		if (head == NULL)
			return;

		do
		{
			swapped = 0;
			ptr1 = head;

			while (ptr1->next != lptr)
			{
				if (ptr1->timeChecker() > ptr1->next->timeChecker())
				{
					swap(ptr1, ptr1->next);
					swapped = 1;
				}
				ptr1 = ptr1->next;
			}
			lptr = ptr1;
		} while (swapped);
	}



//swapping nodes
	void swap(Node* a, Node* b)
	{
		int temp = a->ticketP;
		a->ticketP = b->ticketP;
		b->ticketP = temp;
		string airL = a->airLine;
		a->airLine = b->airLine;
		b->airLine = airL;
		string city = a->city;
		a->city = b->city;
		b->city = city;
		Date date = a->date;
		a->date = b->date;
		b->date = date;
		string dest = a->dest;
		a->dest = b->dest;
		b->dest = dest;
		Time flyT = a->flyingT;
		a->flyingT = b->flyingT;
		b->flyingT =flyT;
		Time landT = a->landingT;
		a->landingT = b->landingT;
		b->landingT = landT;
		int hotelC = a->HotelCharges;
		a->HotelCharges = b->HotelCharges;
		b->HotelCharges = hotelC;
	}
	bool empty() {
		if (head == NULL) {
			return true;
		}
		return false;
	}

// Displaying nodes
	void Display() {
		Node* temp = head;
		while (temp) {
			cout << temp->city << " ";
			cout << temp->dest << " ";
			cout << temp->date << " ";
			cout << temp->flyingT << " ";
			cout << temp->landingT << " ";
			cout << temp->ticketP << " ";
			cout << temp->airLine << " ";
			cout << " Hotel Charges: " << temp->HotelCharges << endl;
			temp = temp->next;
		}
	}
};



// AdjList for Vertices (cities)

struct AdjList {
	
	Edge* edge[50];
	int edgeS =0;
	string city;
	AdjList* next;
	AdjList() {
		next = NULL;
		for (int i = 0; i < 10; i++)
			edge[i] = NULL;
	}
};


class Graph {
	AdjList* head;
public:
	Graph() {
		string array[20];//array for catching cities
		int i = 0;
		fstream file("..//Flights.txt");
		//reading file for cities
		while (!file.eof()) {
			string s;
			getline(file, s, '\n');
			int j;
			int k = 0;
			int count = 0;
			char temp[10];//array for catching cities
			char temp2[10];
			for ( j = 0; s[j] != '\0'; j++) {
				if (s[j] == ' ' && count == 0) {
					count++;
				}
				if (s[j] == ' ' && count==1)
					break;
				if (count==0)
				temp[j] = s[j];
				if (k == -1)
					k++;
				else {
					temp2[k] = s[j];
					k++;
				}
			}
			temp[j] = '\0';
			temp2[k] = '\0';
			bool flag = false;//bool for repeating cities
			bool flag2 = false;
			for (int j = 0; j < i; j++) {
				if (temp == array[j])
					flag = true;
				if (temp2 == array[j])
					flag2 = true;
			}
			if (flag == false && count == 0) {
				array[i] = temp;
				i++;
			}
			flag = false;
			if (flag2 == false && count==1) {
				array[i] = temp2;
				i++;
			}
			flag2 = false;
		}
		for (int j = 0; j < i; j++) {
			if (j == 0) {
				AdjList* n = new AdjList;
				n->city = array[j];
				head = n;
			}
			else {
				AdjList* n = new AdjList;
				n->city = array[j];
				AdjList* cur = head;
				while (cur->next)
				{
					cur = cur->next;
				}
				cur->next = n;
			}
		}

		fstream file1("..//Flights.txt");
		//Reading file for flights data
		while (!file1.eof()) {
			string s;
			getline(file1, s, '\n');
			int j;
			int k = 0;
			int count = 0;
			char temp[16];
			char temp2[16];
			Edge* e = new Edge;
			for (j = 0; s[j] != '\0'; j++) {// converting string to the flights data..
				if (s[j] == ' ') {
					count++;
					if (count == 1) {
						temp[j] = '\0';
						k = 0;
						continue;
					}

					if (count == 2) {
						temp2[k] = '\0';
						k = 0;
						e->dest = temp2;
						continue;
					}
					if (count == 3) {
						temp2[k] = '\0';
						k = 0;
						e->date.convert(temp2);
						continue;
					}
					if (count == 4) {
						temp2[k] = '\0';
						k = 0;
						e->flyingT.convert(temp2);
						continue;
					}
					if (count == 5) {
						temp2[k] = '\0';
						k = 0;
						e->landingT.convert(temp2);
						continue;
					}
					if (count == 6) {
						temp2[k] = '\0';
						k = 0;
						int var = 0;
						stringstream convert(temp2);
						convert >> var;
						e->ticketP = var;
						continue;
					}
				}
				if (count==0){
					temp[j] = s[j];
					k = 0;
				}
				else if (count == 1) {
					temp2[k] = s[j];
					k++;
				}
				else if (count == 2) {
					temp2[k] = s[j];
					k++;
				}
				else if (count == 3) {
					temp2[k] = s[j];
					k++;
				}
				else if (count == 4) {
					temp2[k] = s[j];
					k++;
				}
				else if (count == 5) {
					temp2[k] = s[j];
					k++;
				}
				else if (count == 6) {
					temp2[k] = s[j];
					k++;
					if (s[j+1] == '\0') {
						temp2[k]='\0';
						e->airLine = temp2;
					}
				}
			}
			//  Making cities 
			AdjList* cur = head;
			while ( cur->next!=NULL) {
				if (cur->city == temp) {
					int k=cur->edgeS;
					cur->edge[k] = e;
					cur->edgeS++;
					break;
				}
				cur = cur->next;
			}
		}
		

		// Reading hostels
		fstream Hotel("HotelCharges_perday.txt");
		while (!Hotel .eof()) {
			string s;
			getline(Hotel, s, '\n');
			int count = 0;
			char temp[20];
			char temp2[20];
			int k = 0;
			for (int i = 0; s[i] != '\0'; i++) {
				if (s[i] == ' ') {
					count++;
					if (count==1)
					temp[k] = '\0';
					k = 0;
					continue;
				}
				if (count == 0) {
					temp[k] = s[i];
					k++;
				}
				else {
					temp2[k] = s[i];
					k++;
					if (s[i + 1] == '\0') {
						temp2[k] = '\0';
						stringstream conv(temp2);
						int var=0;
						conv >> var;
						AdjList* cur = head;
						while (cur->next)
						{
							for (int i = 0; i < cur->edgeS; i++) {
								if (cur->edge[i]->dest == temp) {
									cur->edge[i]->HotelCharges = var;
								}
							}
							cur = cur->next;
						}

					}
				}

			}
		}
		//inializing a 3d linked list
		AdjList* temp = head;
		while (temp->next) {
			string city = temp->city;
			AdjList* temp2 = head;
			while (temp2->next) {
				for (int i = 0; i < temp2->edgeS; i++) {
					if (city == temp2->edge[i]->dest) {
						for (int k = 0; k < temp->edgeS; k++) {
							Edge* E = new Edge;
							E->airLine = temp->edge[k]->airLine;
							E->date = temp->edge[k]->date;
							E->dest = temp->edge[k]->dest;
							E->flyingT = temp->edge[k]->flyingT;
							E->landingT = temp->edge[k]->landingT;
							E->HotelCharges = temp->edge[k]->HotelCharges;
							E->ticketP = temp->edge[k]->ticketP;
							E->next = NULL;
							if (temp2->edge[i]->next == NULL)
								temp2->edge[i]->next = E;
							else {
								Edge* temp3 = temp2->edge[i]->next;
								while (temp3->next) {
									temp3 = temp3->next;
								}
								temp3->next = E;
							}
						}
					}
				}
				temp2 = temp2->next;
			}
			temp = temp->next;
		}
	}
	//utility function for showing graph
	void showGraphStructure() {
		AdjList* cur = head;
		while (cur->next)
		{
			cout << cur->city << " ";
			for (int i = 0; i < cur->edgeS; i++) {
				cout << cur->edge[i]->dest << " ";
				cout << cur->edge[i]->HotelCharges << endl;
			}
			cout << endl;
			cur = cur->next;
		}
	}
	
	// function for direct flights
	void showDirectFlights(string origin, string dest,Date date) {
		AdjList* cur = head;
		int count = 0;
		//cout << "=== These are all the flights of your specified Origin to Destination ===\n";
		while (cur->next)
		{
			for (int i = 0; i < cur->edgeS; i++) {
				if (cur->city == origin && cur->edge[i]->dest == dest && cur->edge[i]->date==date) {
					cout << cur->city << " ";
					cout << cur->edge[i]->dest << " ";
					cout << cur->edge[i]->date << " ";
					cout << cur->edge[i]->ticketP << " ";
					cout << cur->edge[i]->airLine<<endl;
					count++;
				}
				else if (cur->city == origin && cur->edge[i]->dest == dest && cur->edge[i]->date.day == (date.day-1)) {
					cout << cur->city << " ";
					cout << cur->edge[i]->dest << " ";
					cout << cur->edge[i]->date << " ";
					cout << cur->edge[i]->ticketP << " ";
					cout << cur->edge[i]->airLine << endl;
					count++;
				}
				else if (cur->city == origin && cur->edge[i]->dest == dest && cur->edge[i]->date.day == (date.day + 1)) {
					cout << cur->city << " ";
					cout << cur->edge[i]->dest << " ";
					cout << cur->edge[i]->date << " ";
					cout << cur->edge[i]->ticketP << " ";
					cout << cur->edge[i]->airLine << endl;
					count++;
				}
			}
				cur = cur->next;
			}
		if (count == 0) {
			cout << "=== There are no flights ===\n";
		}
		}

	//function for showing minimal cost
	void showMinimalCost(string origin, string dest, Date date,string airL) {
		AdjList* cur = head;
		int count = 0;
		List list;
		List L;
		while (cur->next)
		{
			for (int i = 0; i < cur->edgeS; i++) {
				if (count != 3 && cur->city == origin && cur->edge[i]->dest == dest && cur->edge[i]->date == date && cur->edge[i]->airLine==airL) {
					list.insert(cur->edge[i], cur->city);
					count = 1;
				}
				else if (count != 3 && cur->city == origin && cur->edge[i]->dest == dest && cur->edge[i]->date.day == (date.day - 1) && cur->edge[i]->airLine == airL) {
					list.insert(cur->edge[i], cur->city);
					count = 2;
				}
				else if (count != 3 && cur->city == origin && cur->edge[i]->dest == dest && cur->edge[i]->date.day == (date.day + 1) && cur->edge[i]->airLine == airL) {
					list.insert(cur->edge[i], cur->city);
					count = 2;
				}
				else if (count != 1 && count != 2 && cur->city == origin && cur->edge[i]->dest != dest && cur->edge[i]->date.day == date.day && cur->edge[i]->airLine == airL) {
					AdjList* temp = head;
					count = 3;
					while (temp->next) {
						if (temp->city == origin) {
							for (int j = 0; j < temp->edgeS; j++) {
								Edge* E = temp->edge[j]->next;
								while (E) {
									if (E->dest == dest) {
										count = 3;
										L.insertTransit(temp->edge[j], temp->city);
										L.insertTransit(E, temp->edge[j]->dest);
									}
									E = E->next;
								}
							}
						}
						temp = temp->next;
					}
				}
			}
			cur = cur->next;
		}
		if (count == 0 || L.empty()) {
			cout << "=== These are no flights ===\n";
		}
		else if (count == 1) {
			cout << " ==== Flights are availabe on your specified requirements ====\n";
			list.sortCost();
			list.Display();
		}
		else if (count == 2) {
			cout << " ==== Flights are availabe on your specified requirements with one day gap ====\n";
			list.sortCost();
			list.Display();
		}
		else if (count == 3 && !L.empty()) {
			cout << " === There are no Direct Flights ===\n === You can take these Flights to reach your destination ===\n\n";
			L.Display();
			cout << endl;
		}
	}

	//Function for shwowing minimal time..
	void showMinimalTime(string origin, string dest, Date date) {
		AdjList* cur = head;
		int count = 0;
		List list;
		List L;
		while (cur->next)
		{
			for (int i = 0; i < cur->edgeS; i++) {
				if (count != 3 && cur->city == origin && cur->edge[i]->dest == dest && cur->edge[i]->date.day == date.day) {
					list.insert(cur->edge[i], cur->city);
					count = 1;
				}
				else if (count != 3 && cur->city == origin && cur->edge[i]->dest == dest && cur->edge[i]->date.day == (date.day - 1)) {
					list.insert(cur->edge[i], cur->city);
					count = 2;
				}
				else if (count != 3 &&  cur->city == origin && cur->edge[i]->dest == dest && cur->edge[i]->date.day == (date.day + 1)) {
					list.insert(cur->edge[i], cur->city);
					count = 2;
				}
				else if (count != 1 && count != 2 && cur->city == origin && cur->edge[i]->dest != dest && cur->edge[i]->date.day == date.day) {
					AdjList* temp = head;
					while (temp->next) {
						if (temp->city == origin) {
							for (int j = 0; j < temp->edgeS; j++) {
								Edge* E = temp->edge[j]->next;
								while (E) {
									if (E->dest == dest) {
										count = 3;
										L.insertTransit(temp->edge[j], temp->city);
										L.insertTransit(E, temp->edge[j]->dest);
									}
									E = E->next;
								}
							}
						}
						temp = temp->next;
					}
				}
			}
			cur = cur->next;
		}
		if (count == 0 && L.empty()) {
			cout << "=== These are no flights ===\n";
		}
		else if (count == 1 ) {
			cout << " ==== Flights are availabe on your specified requirements ====\n";
			list.sortTime();
			list.Display();
		}
		else if (count == 2) {
			cout << " ==== Flights are availabe on your specified requirements with one day gap ====\n";
			list.sortTime();
			list.Display();
		}
		else if (count == 3 && !L.empty()) {
			cout << " === There are no Direct Flights ===\n === You can take these Flights to reach your destination ===\n\n";
			L.Display();
			cout << endl;
		}
	}

	//Fuctions for transit...
	void showTransitStay(string origin, string dest, Date date, string transit) {

		AdjList* cur = head;
		int count = 0;
		int count2 = 0;
		List list;
		List L;
		AdjList* temp = head;
		while (temp->next) {
			if (temp->city == origin) {
				for (int j = 0; j < temp->edgeS; j++) {
					Edge* E = temp->edge[j]->next;
					while (E) {
						if (E->dest == dest) {
							count = 3;
							if (temp->edge[j]->dest == transit) {
								if (temp->edge[j]->date == date && E->date==date) {
									L.insertTransit(temp->edge[j], temp->city);
									L.insertTransit(E, temp->edge[j]->dest);
								}
								else {
									list.insertTransit(temp->edge[j], temp->city);
									list.insertTransit(E, temp->edge[j]->dest);
									count2 = 1;
								}
							}
						}
						E = E->next;
					}
				}
			}
			temp = temp->next;
		}		
		if (count == 0 && L.empty()) {
			cout << "=== These are no flights ===\n";
		}
		if (count == 3 && !L.empty()) {
			cout << "=== You can take these Flights===\n\n";
			L.Display();
			cout << endl;
		}
		else if(count2 == 1 && L.empty()) {
			cout << "=== You can take these Flights On different Dates ===\n\n";
			list.Display();
			cout << endl;
		}
	}
	//Fuctions for Minimal transit time ...
	void showTransitTime(string origin, string dest, Date date, string transit) {

		AdjList* cur = head;
		int count = 0;
		int count2 = 0;
		List list;// two list for different date handling
		List L;
		AdjList* temp = head;
		while (temp->next) {
			if (temp->city == origin) {
				for (int j = 0; j < temp->edgeS; j++) {
					Edge* E = temp->edge[j]->next;
					while (E) {
						if (E->dest == dest) {
							count = 3;
							if (temp->edge[j]->dest == transit) {
								if (temp->edge[j]->date == date && E->date == date) {
									L.insertTransit(temp->edge[j], temp->city);
									L.insertTransit(E, temp->edge[j]->dest);
								}
								else {
									list.insertTransit(temp->edge[j], temp->city);
									list.insertTransit(E, temp->edge[j]->dest);
									count2 = 1;
								}
							}
						}
						E = E->next;
					}
				}
			}
			temp = temp->next;
		}
		if (count == 0 && L.empty()) {
			cout << "=== These are no flights ===\n";
		}
		if (count == 3 && !L.empty()) {
			cout << "=== You can take these Flights===\n\n";
			L.sortTime();
			L.Display();
			cout << endl;
		}
		else if (count2 == 1 && L.empty()) {
			cout << "=== You can take these Flights On different starting Dates ===\n\n";
			list.sortTime();
			list.Display();
			cout << endl;
		}
	}
	~Graph() {
		delete head;
	}
};

  
int main() {
	Graph g;
	string origin, dest, date, airL,transit;
	int cost;

	cout << " ===== Enter All the Entries ======= \n";
	cout << " Enter Origin : ";
	getline(cin, origin);
	cout << " Enter Destination : ";
	getline(cin, dest);
	cout << " Enter date (dd/mm/yyyy): ";
	getline(cin, date);
	
	Date d;
	d.convert(date);

	cout << " =====================  Flight Reservation System  ===========================\n";
	cout << " 1. Scenario 1 (Cost Effective) \n";
	cout << " 2. Scenario 2 (Time Effective) \n";
	cout << " 3. Scenario 3 (Transit Effective) \n";
	cout << " 4. Scenario 4 (Transit Time Effective) \n";
	cout << " 5. Scenario 5 (Direct Flights) \n";
	cout << " Enter Your Choice : ";
	int choice;
	cin >> choice;
	switch (choice) {
	case 1:
		cin.ignore();
		cout << " Enter AirLine : ";
		getline(cin, airL);
		g.showMinimalCost(origin, dest, d, airL);
		break;
	case 2:
		g.showMinimalTime(origin, dest, d);
		break;
	case 3:
		cin.ignore();
		cout << " Enter Transit : ";
		getline(cin, transit);
		g.showTransitStay(origin, dest, d, transit);
		break;
	case 4:
		cin.ignore();
		cout << " Enter Transit : ";
		getline(cin, transit);
		g.showTransitTime(origin, dest, d, transit);
		break;
	case 5:
		g.showDirectFlights(origin, dest, d);
		break;
	}	
	return 0;
}